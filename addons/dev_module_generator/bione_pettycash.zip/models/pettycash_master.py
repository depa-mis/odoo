# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################
from odoo import models, fields, api, _

class pettycash_master(models.Model):
	_name = 'pettycash.master'

	amount_fix = fields.Float(string='Amount Fix', required=1)
	pettycash_depart = fields.Many2one('hr.department', string='Petty Cash Depart', required=1)



# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: