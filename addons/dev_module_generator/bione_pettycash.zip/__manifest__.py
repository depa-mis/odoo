# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################
{
	'name':'BiOne Pettycash',
	'category':'Account', 
	'summary':'petty cash for company', 
	'description':'''Petty Cash''', 
	'author':'bione solutions ltd.com', 
	'website':'www.thaiodoo.com', 
	'version':'1.0', 
	'depends':['account'],
	'sequence':1, 
	'data':['views/menu_file.xml', 'views/pettycash_master_views.xml'],
	'installable':True, 
	'application':True, 
	'auto_install':False, 
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: